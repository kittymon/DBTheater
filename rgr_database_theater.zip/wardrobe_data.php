<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf-8">
<title>Cleaners</title>
<link rel="stylesheet" type="text/css" href="substyle.css">
</head>
<body>
<?php
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}
// show tables in web page
function getPostsW()
			{
			    $postsW[1] = $_POST['wrd_id'];
			    $postsW[2] = $_POST['wrd_name'];
			    $postsW[3] = $_POST['wrd_salary'];
			    $postsW[4] = $_POST['wrd_timetable'];
				$postsW[5] = $_POST['bff_id'];
			    return $postsW;
			}
			$sql = "SELECT * FROM wardrobe_worker ORDER BY 'ASC' LIMIT 20";

				if (!$result = mysqli_query($conk, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '5'>Data about wardrobe worker</tr></th></thead>\n";
				while ($wardrobe_worker = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $wardrobe_worker['wrd_id'] . "</td><td>". $wardrobe_worker['wrd_name'] . "</td><td>" . $wardrobe_worker['wrd_salary'] . "</td><td>" . $wardrobe_worker['wrd_timetable']. "</td><td>" . $wardrobe_worker['bff_id']. "</td>" ;
				    echo "</tr>";
				}
				

			echo "</table>\n";
			// add new data
			if(isset($_POST['add']))
			{
			    $data = getPostsW();
			    $insert_Query = "INSERT INTO `wardrobe_worker`(`wrd_id`, `wrd_name`, `wrd_salary`, `wrd_timetable`, `bff_id`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]')";
			    try{
			        $insert_Result = mysqli_query($conk, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Adding was succsessfull!';
			            }else{
			                echo 'Data wasn`t added! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t add your data! Error: '.$ex->getMessage();
			    }
			}
			// delete some data
			if(isset($_POST['delete']))
			{
			    $data = getPostsW();
			    $delete_Query = "DELETE FROM `wardrobe_worker` WHERE `wrd_id` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($conk, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Deleting was succsesfully!';
			            }else{
			                echo 'Data wasn`t deleted! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: can`t delete your data!'.$ex->getMessage();
			    }
			}
			// show updated tables
				if(isset($_POST['update']))
			{
			    $data = getPostsW();
			    $update_Query = "UPDATE `wardrobe_worker` SET `wrd_id`='$data[1]',`wrd_name`='$data[2]',`wrd_salary`='$data[3],`wrd_timetable`='$data[4]',`bff_id`='$data[5]' WHERE `wrd_id` = $data[0]";
			    try{
			        $update_Result = mysqli_query($conk, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error Update '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="wardrobe_data.php" method="post"><br><br>
     <input type="number" name = "wrd_id" placeholder = "id" value="<?php echo $wrd_id;?>"><br><br>
		<input type="text" name = "wrd_name" placeholder = "name" value="<?php echo $wrd_name;?>"><br><br>
		<input type="number" name = "wrd_salary" placeholder = "salary" value="<?php echo $wrd_salary;?>"><br><br>
		<input type="datetime-local" name = "wrd_timetable" placeholder = "timetable" value="<?php echo $wrd_timetable;?>"><br><br>
		<input type="number" name = "bff_id" placeholder = "buffet worker id" value="<?php echo $bff_id;?>"><br><br>
		<div>
		    <input type="submit" name = "add" value="Add worker">
			<input type="submit" name = "delete" value="Delete worker">
			<input type="submit" name = "update" value="Update the table">
		</div>
	</form>
</html>