<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf-8">
<title>Cashiers</title>
<link rel="stylesheet" type="text/css" href="substyle.css">
</head>
<body>
<?php
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}
// show tables in web page
function getPostsC()
			{
			    $postsC = array();
			    $postsC[1] = $_POST['tcc_id'];
			    $postsC[2] = $_POST['tcc_name'];
			    $postsC[3] = $_POST['tcc_salary'];
			    $postsC[4] = $_POST['tcc_timetable'];
				$postsC[5] = $_POST['bff_id'];
			    return $postsC;
			}
			$sql = "SELECT * FROM ticket_cashier ORDER BY 'ASC' LIMIT 20";

				if (!$result = mysqli_query($conk, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '5'>Data about cashiers</tr></th></thead>\n";
				while ($ticket_cashier = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $ticket_cashier['tcc_id'] . "</td><td>". $ticket_cashier['tcc_name'] . "</td><td>" . $ticket_cashier['tcc_salary'] . "</td><td>" . $ticket_cashier['tcc_timetable']. "</td><td>" . $ticket_cashier['bff_id']. "</td>" ;
				    echo "</tr>";
				}
				

			echo "</table>\n";
			// add new data
			if(isset($_POST['add']))
			{
			    $data = getPostsC();
			    $insert_Query = "INSERT INTO `ticket_cashier`(`tcc_id`, `tcc_name`, `tcc_salary`, `tcc_timetable`, `bff_id`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]')";
			    try{
			        $insert_Result = mysqli_query($conk, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Adding was succsessfull!';
			            }else{
			                echo 'Data wasn`t added! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t add your data! Error: '.$ex->getMessage();
			    }
			}
			// delete some data
			if(isset($_POST['delete']))
			{
			    $data = getPostsC();
			    $delete_Query = "DELETE FROM `ticket_cashier` WHERE `tcc_id` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($conk, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Deleting was succsesfully!';
			            }else{
			                echo 'Data wasn`t deleted! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t delete your data! Error:'.$ex->getMessage();
			    }
			}
			// show updated tables
			if(isset($_POST['update']))
			{
			    $data = getPostsC();
			    $update_Query = "UPDATE `ticket_cashier` SET `tcc_id`='$data[1]',`tcc_name`='$data[2]',`tcc_salary`='$data[3]',`tcc_timetable`='$data[4]',`bff_id`='$data[5]' WHERE `tcc_id` = '$data[0]'";
			    try{
			        $update_Result = mysqli_query($conk, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No Updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: can`t update the table! Please, try again! '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="cashier_data.php" method="post"><br><br>
        <input type="number" name = "tcc_id" placeholder = "id" value="<?php echo $tcc_id;?>"><br><br>
		<input type="text" name = "tcc_name" placeholder = "name" value="<?php echo $tcc_name;?>"><br><br>
		<input type="number" name = "tcc_salary" placeholder = "salary" value="<?php echo $tcc_salary;?>"><br><br>
		<input type="datetime-local" name = "tcc_timetable" placeholder = "timetable" value="<?php echo $tcc_timetable;?>"><br><br>
		<input type="number" name = "bff_id" placeholder = "buffet worker id" value="<?php echo $bff_id;?>"><br><br>
		
		<div>
		    <input type="submit" name = "add" value="Add cashier">
			<input type="submit" name = "delete" value="Delete cashier">
			<input type="submit" name = "update" value="Update the table">
		</div>
	</form>
</html>