<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf-8">
<title>Visitors</title>
<link rel="stylesheet" type="text/css" href="substyle.css">
</head>
<body>
<?php
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}
// show tables in web page
function getPostsB()
			{
			    $postsB = array();
			    $postsB[1] = $_POST['vis_id'];
			    $postsB[2] = $_POST['vis_name'];
			    $postsB[3] = $_POST['vis_email'];
				$postsB[4] = $_POST['tick_id'];
				$postsB[5] = $_POST['tcc_id'];
				$postsB[6] = $_POST['tch_id'];
				$postsB[7] = $_POST['bff_id'];
				$postsB[8] = $_POST['wrd_id'];
			    return $postsB;
			}
			$sql = "SELECT * FROM visitor ORDER BY 'ASC' ";

				if (!$result = mysqli_query($conk, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '8'>Data about visitors</tr></th></thead>\n";
				while ($visitor = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $visitor['vis_id'] . "</td><td>". $visitor['vis_name'] . "</td><td>" . $visitor['vis_email'] . "</td><td>" . $visitor['tick_id']. "</td><td>" . $visitor['tcc_id']. "</td><td>" . $visitor['tch_id']. "</td><td>" . $visitor['bff_id']. "</td><td>" . $visitor['wrd_id'] . "</td>" ;
				    echo "</tr>";
				}

			echo "</table>\n";
				// add new data
			if(isset($_POST['add']))
			{
			    $data = getPostsB();
				$var_email = $_POST['vis_email'];
                     if (filter_var($var_email, FILTER_VALIDATE_EMAIL)) {
                           echo "It`s OK! Email is correct!";
                        } else {
                          echo "Warning! Email is`nt correct! Please, edit your data after updation!\n";
                        }
						$sanitized= filter_var($var_email, FILTER_SANITIZE_EMAIL);
						if (filter_var($sanitized, FILTER_VALIDATE_EMAIL)) {
                        echo "Tips for email:\n";
                        echo "Before  $var_email\n";
                        echo "After  $sanitized\n";
}
			    $insert_Query = "INSERT INTO `visitor`(`vis_id`, `vis_name`, `vis_email`, `tick_id`, `tcc_id`, `tch_id`, `bff_id`, `wrd_id`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]')";
			    try{
			        $insert_Result = mysqli_query($conk, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Data was added!';
			            }else{
			                echo 'Data wasn`t added! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t add your data! Error: '.$ex->getMessage();
			    }
			}
			// delete some data
			if(isset($_POST['delete']))
			{
			    $data = getPostsB();
			    $delete_Query = "DELETE FROM `visitor` WHERE `vis_id` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($conk, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Deleting was succsesfull!';
			            }else{
			                echo 'Data wasn`t deleted! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t delete your data! Error: '.$ex->getMessage();
			    }
			}

			// show updated tables
			if(isset($_POST['update']))
			{
			    $data = getPostsB();
			    $update_Query = "UPDATE `visitor` SET `vis_id`='$data[1]',`vis_name`='$data[2]',`vis_email`='$data[3]',`tick_id`='$data[4]', `tcc_id`='$data[5]' , `tch_id`='$data[6]', `bff_id`='$data[7]', `wrd_id`='$data[8]' WHERE `vis_id` = '$data[0]'";
			    try{
			        $update_Result = mysqli_query($conk, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No Updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: can`t update the table! Please, try again! '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="visitors.php" method="post"><br><br>
		<input type="number" name = "vis_id" placeholder = "id" value="<?php echo $vis_id;?>"><br><br>
		<input type="text" name = "vis_name" placeholder = "name" value="<?php echo $vis_name;?>"><br><br>
		<input type="text" name = "vis_email" placeholder = "email" value="<?php echo $vis_email;?>"><br><br>
		<input type="number" name = "tick_id" placeholder = "ticket id" value="<?php echo $tick_id;?>"><br><br>
		<input type="number" name = "tcc_id" placeholder = "ticket cashier id" value="<?php echo $tcc_id;?>"><br><br>
		<input type="number" name = "tch_id" placeholder = "ticket checker id" value="<?php echo $tch_id;?>"><br><br>
		<input type="number" name = "bff_id" placeholder = "buffet worker id" value="<?php echo $bff_id;?>"><br><br>
		<input type="number" name = "wrd_id" placeholder = "wardrobe worker id" value="<?php echo $wrd_id;?>"><br><br>
		
		<div>
		    <input type="submit" name = "add" value="Add visitor">
			<input type="submit" name = "delete" value="Delete visitor">
			<input type="submit" name = "update" value="Update the table">
		</div>
	</form>
</html>