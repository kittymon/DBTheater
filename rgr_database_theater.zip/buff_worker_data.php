<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf-8">
<title>Buffet workers</title>
<link rel="stylesheet" type="text/css" href="substyle.css">
</head>
<body>
<?php
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}
// show tables in web page
function getPostsBf()
			{
			    $postsBf[1] = $_POST['bff_id'];
			    $postsBf[2] = $_POST['bff_name'];
			    $postsBf[3] = $_POST['bff_salary'];
			    $postsBf[4] = $_POST['bff_timetable'];
			    return $postsBf;
			}
			$sql = "SELECT * FROM buffet_worker ORDER BY 'ASC' LIMIT 20";

				if (!$result = mysqli_query($conk, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '4'>Data about buffet workers</tr></th></thead>\n";
				while ($buffet_worker = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $buffet_worker['bff_id'] . "</td><td>". $buffet_worker['bff_name'] . "</td><td>" . $buffet_worker['bff_salary'] . "</td><td>" . $buffet_worker['bff_timetable'] . "</td>" ;
				    echo "</tr>";
				}
				

			echo "</table>\n";
			// add new data
			if(isset($_POST['add']))
			{
			    $data = getPostsBf();
			    $insert_Query = "INSERT INTO `buffet_worker`(`bff_id`, `bff_name`, `bff_salary`, `bff_timetable`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]')";
			    try{
			        $insert_Result = mysqli_query($conk, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Adding was succsessfull!';
			            }else{
			                echo 'Data wasn`t added! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t add your data! Error: '.$ex->getMessage();
			    }
			}
			// delete some data
			if(isset($_POST['delete']))
			{
			    $data = getPostsBf();
			    $delete_Query = "DELETE FROM `buffet_worker` WHERE `bff_id` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($conk, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Deleting was succsesfully!';
			            }else{
			                echo 'Data wasn`t deleted! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: can`t delete your data!'.$ex->getMessage();
			    }
			}
			// show updated tables
				if(isset($_POST['update']))
			{
			    $data = getPostsBf();
			    $update_Query = "UPDATE `buffet_worker` SET `bff_id`='$data[1]',`bff_name`='$data[2]',`bff_salary`='$data[3],`bff_timetable`='$data[4]' WHERE `bff_id` = $data[0]";
			    try{
			        $update_Result = mysqli_query($conk, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error Update '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="buff_worker_data.php" method="post"><br><br>
        <input type="number" name = "bff_id" placeholder = "id" value="<?php echo $bff_id;?>"><br><br>
		<input type="text" name = "bff_name" placeholder = "name" value="<?php echo $bff_name;?>"><br><br>
		<input type="number" name = "bff_salary" placeholder = "salary" value="<?php echo $bff_salary;?>"><br><br>
		<input type="datetime-local" name = "bff_timetable" placeholder = "timetable" value="<?php echo $bff_timetable;?>"><br><br>
		
		<div>
		    <input type="submit" name = "add" value="Add worker">
			<input type="submit" name = "delete" value="Delete worker">
			<input type="submit" name = "update" value="Update the table">
		</div>
	</form>
</html>