<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Tickets</title>
<link rel="stylesheet" type="text/css" href="substyle.css">
</head>
<body>
<?php
// show tables in web page
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}
function getPostsT()
			{
			    $postsT = array();
			    $postsT[1] = $_POST['tick_id'];
			    $postsT[2] = $_POST['tick_cost'];
			    $postsT[3] = $_POST['tick_sit'];
			    $postsT[4] = $_POST['tick_data'];
				$postsT[5] = $_POST['tick_play_name'];
				$postsT[6] = $_POST['vis_id'];
			    $postsT[7] = $_POST['tcc_id'];
				$postsT[8] = $_POST['tch_id'];
			
			    return $postsT;
			}
			$sql = "SELECT * FROM ticket ORDER BY 'ASC' LIMIT 15";

				if (!$result = mysqli_query($conk, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '8'>Data about tickets </tr></th></thead>\n";
				while ($ticket = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $ticket['tick_id'] . "</td><td>". $ticket['tick_cost'] . "</td><td>" . $ticket['tick_sit'] . "</td><td>" . $ticket['tick_data'] ."</td><td>".$ticket['tick_play_name']."</td><td>".$ticket['vis_id']."</td><td>".$ticket['tcc_id']."</td><td>".$ticket['tch_id']. "</td>" ;
				    echo "</tr>";
				}

			echo "</table>\n";
			// add new data
			if(isset($_POST['add']))
			{
			    $data = getPostsT();
			    $insert_Query = "INSERT INTO `ticket`(`tick_id`, `tick_cost`, `tick_sit`, `tick_data`, `tick_play_name`, `vis_id`, `tcc_id`, `tch_id` ) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]')";
			    try{
			        $insert_Result = mysqli_query($conk, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Adding was succsessfull!';
			            }else{
			                echo 'Data wasn`t added! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t add your data! Error: '.$ex->getMessage();
			    }
			}
			// delete some data
			if(isset($_POST['delete']))
			{
			    $data = getPostsT();
			    $delete_Query = "DELETE FROM `ticket` WHERE `tick_id` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($conk, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Deleting was succsesfully!';
			            }else{
			                echo 'Data wasn`t deleted! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: can`t delete your data!'.$ex->getMessage();
			    }
			}
			// show updated tables
			if(isset($_POST['update']))
			{
			    $data = getPostsT();
			    $update_Query = "UPDATE `ticket` SET `tick_id`='$data[1]',`tick_cost`='$data[2]',`tick_sit`='$data[3],`tick_data`='$data[4]',`tick_play_name`='$data[5]',`vis_id`='$data[6]',`tcc_id`='$data[7]',`tch_id`='$data[8]' WHERE `tick_id` = $data[0]";
			    try{
			        $update_Result = mysqli_query($conk, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error Update '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="tickets.php" method="post"><br><br>
        <input type="number" name = "tick_id" placeholder = "id" value="<?php echo $tick_id;?>"><br><br>
		<input type="number" name = "tick_cost" placeholder = "cost" value="<?php echo $tick_cost;?>"><br><br>
		<input type="number" name = "tick_sit" placeholder = "sit" value="<?php echo $tick_sit;?>"><br><br>
		<input type="datetime-local" name = "tick_data" placeholder = "data" value="<?php echo $tick_data;?>"><br><br>
		<input type="text" name = "tick_play_name" placeholder = "play name" value="<?php echo $tick_play_name;?>"><br><br>
		<input type="number" name = "vis_id" placeholder = "visitor`s id" value="<?php echo $vis_id;?>"><br><br>
		<input type="number" name = "tcc_id" placeholder = "cashier`s id" value="<?php echo $tcc_id;?>"><br><br>
		<input type="number" name = "tch_id" placeholder = "checker`s id" value="<?php echo $tch_id;?>"><br><br>
		
		    <input type="submit" name = "add" value="Add ticket">
			<input type="submit" name = "delete" value="Delete ticket">
			<input type="submit" name = "update" value="Update the table">
		</div>
	</form>
</html>