<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Main page</title>
<link rel="stylesheet" type="text/css" href="mainstyle.css">
</head>
<body>
<?php
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}
echo "Database was connected succsesfully!";
?>
</body>
<h1>Welcome to the Theater`s Database! </h1>
<h2> Please, choose a page for your further work by clicking one button here: </h2>
<div>
<button onclick="window.location.href = 'visitors.php';">Visitors</button>
<button onclick="window.location.href = 'workers.php';" >Workers</button>
<button onclick="window.location.href = 'items.php';">Items</button>
<button onclick="window.location.href = 'actors.php';">Actor`s cast</button>	
</div>
</html>
