<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Tickets</title>
<link rel="stylesheet" type="text/css" href="substyle.css">
</head>
<body>
<?php
// show tables in web page
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}
function getPostsF()
			{
			    $postsF[1] = $_POST['fd_id'];
			    $postsF[2] = $_POST['fd_name'];
			    $postsF[3] = $_POST['fd_type'];
				$postsF[4] = $_POST['fd_count'];
				$postsF[5] = $_POST['fd_cost'];
			    $postsF[6] = $_POST['vis_id'];
				$postsF[7] = $_POST['bff_id'];
			
			    return $postsF;
			}
			$sql = "SELECT * FROM food ORDER BY 'ASC' LIMIT 15";

				if (!$result = mysqli_query($conk, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '5'>Data about food in buffet </tr></th></thead>\n";
				while ($food = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $food['fd_id'] . "</td><td>". $food['fd_name'] . "</td><td>" . $food['fd_type'] . "</td><td>" . $food['fd_count'] ."</td><td>". $food['fd_cost']."</td><td>". $food['vis_id']."</td><td>". $food['bff_id'] ."</td>" ;
				    echo "</tr>";
				}


			echo "</table>\n";
			// add new data
			if(isset($_POST['add']))
			{
			    $data = getPostsF();
			    $insert_Query = "INSERT INTO `food`(`fd_id`, `fd_name`, `fd_type`, `fd_count`, `fd_cost`, `vis_id`, `bff_id` ) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]')";
			    try{
			        $insert_Result = mysqli_query($conk, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Adding was succsessfull!';
			            }else{
			                echo 'Data wasn`t added! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t add your data! Error: '.$ex->getMessage();
			    }
			}
			// delete some data
			if(isset($_POST['delete']))
			{
			    $data = getPostsF();
			    $delete_Query = "DELETE FROM `food` WHERE `fd_id` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($conk, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Deleting was succsesfully!';
			            }else{
			                echo 'Data wasn`t deleted! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: can`t delete your data!'.$ex->getMessage();
			    }
			}
			// show updated tables
			if(isset($_POST['update']))
			{
			    $data = getPostsF();
			    $update_Query = "UPDATE `food` SET `fd_id`='$data[1]',`fd_name`='$data[2]',`fd_type`='$data[3],`fd_count`='$data[4]',`fd_cost`='$data[5]',`vis_id`='$data[6]',`bff_id`='$data[7]' WHERE `fd_id` = $data[0]";
			    try{
			        $update_Result = mysqli_query($conk, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error Update '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="foods.php" method="post"><br><br>
        <input type="number" name = "fd_id" placeholder = "id" value="<?php echo $fd_id;?>"><br><br>
		<input type="text" name = "fd_name" placeholder = "name" value="<?php echo $fd_name;?>"><br><br>
		<input type="text" name = "fd_type" placeholder = "type" value="<?php echo $fd_type;?>"><br><br>
		<input type="number" name = "fd_count" placeholder = "count" value="<?php echo $fd_count;?>"><br><br>
		<input type="number" name = "fd_cost" placeholder = "cost" value="<?php echo $fd_cost;?>"><br><br>
		<input type="number" name = "vis_id" placeholder = "visitor`s id" value="<?php echo $vis_id;?>"><br><br>
		<input type="number" name = "bff_id" placeholder = "buffet worker`s id" value="<?php echo $bff_id;?>"><br><br>
		
		
		    <input type="submit" name = "add" value="Add food">
			<input type="submit" name = "delete" value="Delete food">
			<input type="submit" name = "update" value="Update the table">
		</div>
	</form>
</html>