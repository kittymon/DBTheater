<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Actors</title>
<link rel="stylesheet" type="text/css" href="substyle.css">
</head>
<body>
<?php
// show tables in web page
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}

function getPostsA()
			{
			    $postsA = array();
			    $postsA[1] = $_POST['act_id'];
			    $postsA[2] = $_POST['act_name'];
			    $postsA[3] = $_POST['act_salary'];
			    $postsA[4] = $_POST['act_timetable'];
				$postsA[5] = $_POST['act_play'];
			    $postsA[6] = $_POST['act_role'];
				$postsA[7] = $_POST['bff_id'];
			    return $postsA;
			}
			$sql = "SELECT * FROM actor ORDER BY 'ASC' LIMIT 15";

				if (!$result = mysqli_query($conk, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '7'>Actors data</tr></th></thead>\n";
				while ($actor = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $actor['act_id'] . "</td><td>". $actor['act_name'] . "</td><td>" . $actor['act_salary'] . "</td><td>" . $actor['act_timetable'] . "</td><td>" . $actor['act_play'] ."</td><td>". $actor['act_role']."</td><td>". $actor['bff_id']. "</td>" ;
				    echo "</tr>";
				}
			echo "</table>\n";
			// add new data
			if(isset($_POST['add']))
			{
			    $data = getPostsA();
			    $insert_Query = "INSERT INTO `actor`(`act_id`, `act_name`, `act_salary`, `act_timetable`, `act_play`, `act_role`, `bff_id` ) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]')";
			    try{
			        $insert_Result = mysqli_query($conk, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Adding was succsessfull!';
			            }else{
			                echo 'Data wasn`t added! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t add your data! Error: '.$ex->getMessage();
			    }
			}
			// delete some data
			if(isset($_POST['delete']))
			{
			    $data = getPostsA();
			    $delete_Query = "DELETE FROM `actor` WHERE `act_id` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($conk, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Deleting was succsesfully!';
			            }else{
			                echo 'Data wasn`t deleted! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: can`t delete your data!'.$ex->getMessage();
			    }
			}
			// show updated tables
			if(isset($_POST['update']))
			{
			    $data = getPostsA();
			    $update_Query = "UPDATE `actor` SET `act_id`='$data[1]',`act_name`='$data[2]',`act_salary`='$data[3],`act_timetable`='$data[4]',`act_play`='$data[5]',`act_role`='$data[6]',`bff_id`='$data[7]' WHERE `act_id` = $data[0]";
			    try{
			        $update_Result = mysqli_query($conk, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error Update '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="actor.php" method="post"><br><br>
        <input type="number" name = "act_id" placeholder = "id" value="<?php echo $act_id;?>"><br><br>
		<input type="text" name = "act_name" placeholder = "name" value="<?php echo $act_name;?>"><br><br>
		<input type="number" name = "act_salary" placeholder = "salary" value="<?php echo $act_salary;?>"><br><br>
		<input type="time" name = "act_timetable" placeholder = "timetable" value="<?php echo $act_timetable;?>"><br><br>
		<input type="text" name = "act_play" placeholder = "play" value="<?php echo $act_play;?>"><br><br>
		<input type="text" name = "act_role" placeholder = "role" value="<?php echo $act_role;?>"><br><br>
		<input type="number" name = "bff_id" placeholder = "buffet worker id" value="<?php echo $bff_id;?>"><br><br>
		

		<div>
		    <input type="submit" name = "add" value="Add actor">
			<input type="submit" name = "delete" value="Delete actor">
			<input type="submit" name = "update" value="Update the table">
		</div>
	</form>
</html>