<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf-8">
<title>Checkers</title>
<link rel="stylesheet" type="text/css" href="substyle.css">
</head>
<body>
<?php
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}
// show tables in web page
function getPostsCh()
			{
			    $postsCh[1] = $_POST['tch_id'];
			    $postsCh[2] = $_POST['tch_name'];
			    $postsCh[3] = $_POST['tch_salary'];
			    $postsCh[4] = $_POST['tch_timetable'];
				$postsCh[5] = $_POST['bff_id'];
			    return $postsCh;
			}
			$sql = "SELECT * FROM ticket_checker ORDER BY 'ASC' LIMIT 20";

				if (!$result = mysqli_query($conk, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '5'>Data about checkers</tr></th></thead>\n";
				while ($ticket_checker = $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $ticket_checker['tch_id'] . "</td><td>". $ticket_checker['tch_name'] . "</td><td>" . $ticket_checker['tch_salary'] . "</td><td>" . $ticket_checker['tch_timetable']. "</td><td>" . $ticket_checker['bff_id'] . "</td>" ;
				    echo "</tr>";
				}
				

			echo "</table>\n";
			// add new data
			if(isset($_POST['add']))
			{
			    $data = getPostsCh();
			    $insert_Query = "INSERT INTO `ticket_checker`(`tch_id`, `tch_name`, `tch_salary`, `tch_timetable`, `bff_id`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]')";
			    try{
			        $insert_Result = mysqli_query($conk, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Adding was succsessfull!';
			            }else{
			                echo 'Data wasn`t added! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t add your data! Error: '.$ex->getMessage();
			    }
			}
			// delete some data
			if(isset($_POST['delete']))
			{
			    $data = getPostsCh();
			    $delete_Query = "DELETE FROM `ticket_checker` WHERE `tch_id` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($conk, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Deleting was succsesfully!';
			            }else{
			                echo 'Data wasn`t deleted! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: can`t delete your data!'.$ex->getMessage();
			    }
			}
			// show updated tables
				if(isset($_POST['update']))
			{
			    $data = getPostsCh();
			    $update_Query = "UPDATE `ticket_checker` SET `tch_id`='$data[1]',`tch_name`='$data[2]',`tch_salary`='$data[3],`tch_timetable`='$data[4]', `bff_id`='$data[5]' WHERE `tch_id` = $data[0]";
			    try{
			        $update_Result = mysqli_query($conk, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: can`t update the table! Please, try again!'.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="checkers_data.php" method="post"><br><br>
        <input type="number" name = "tch_id" placeholder = "id" value="<?php echo $tch_id;?>"><br><br>
		<input type="text" name = "tch_name" placeholder = "name" value="<?php echo $tch_name;?>"><br><br>
		<input type="number" name = "tch_salary" placeholder = "salary" value="<?php echo $tch_salary;?>"><br><br>
		<input type="datetime-local" name = "tch_timetable" placeholder = "timetable" value="<?php echo $tch_timetable;?>"><br><br>
		<input type="number" name = "bff_id" placeholder = "buffet worker id" value="<?php echo $bff_id;?>"><br><br>
		
		<div>
		    <input type="submit" name = "add" value="Add checker">
			<input type="submit" name = "delete" value="Delete checker">
			<input type="submit" name = "update" value="Update the table">
		</div>
	</form>
</html>