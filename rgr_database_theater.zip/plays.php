<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Plays</title>
<link rel="stylesheet" type="text/css" href="substyle.css">
</head>
<body>
<?php
// show tables in web page
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}

function getPostsP()
			{
			    $postsP[1] = $_POST['pl_id'];
			    $postsP[2] = $_POST['pl_name'];
				$postsP[3] = $_POST['pl_author'];
			    $postsP[4] = $_POST['pl_timetable'];
			    $postsP[5] = $_POST['pl_roles'];
				$postsP[6] = $_POST['act_id'];
			    return $postsP;
			}
			$sql = "SELECT * FROM play ORDER BY 'ASC' LIMIT 15";

				if (!$result = mysqli_query($conk, $sql)) {
			    echo "Error.";
			    exit;
			}

			echo "<table>\n";
			echo "<thead><tr><th colspan = '6'>Plays data</tr></th></thead>\n";
				while ($play= $result->fetch_assoc()) {
					echo "<tr>\n";
				    echo "<td>" . $play['pl_id'] . "</td><td>". $play['pl_name'] . "</td><td>" . $play['pl_author'] . "</td><td>" . $play['pl_timetable'] . "</td><td>". $play['pl_roles']."</td><td>". $play['act_id'] ."</td>" ;
				    echo "</tr>";
				}
			echo "</table>\n";
			// add new data
			if(isset($_POST['add']))
			{
			    $data = getPostsP();
			    $insert_Query = "INSERT INTO `play`(`pl_id`, `pl_name`, `pl_author`, `pl_timetable`, `pl_roles`, `act_id` ) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]')";
			    try{
			        $insert_Result = mysqli_query($conk, $insert_Query);
			        
			        if($insert_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Adding was succsessfull!';
			            }else{
			                echo 'Data wasn`t added! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Can`t add your data! Error: '.$ex->getMessage();
			    }
			}
			// delete some data
			if(isset($_POST['delete']))
			{
			    $data = getPostsP();
			    $delete_Query = "DELETE FROM `play` WHERE `pl_id` = $data[1]";
			    try{
			        $delete_Result = mysqli_query($conk, $delete_Query);
			        
			        if($delete_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Deleting was succsesfully!';
			            }else{
			                echo 'Data wasn`t deleted! Please, try again!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error: can`t delete your data!'.$ex->getMessage();
			    }
			}
			// show updated tables
				if(isset($_POST['update']))
			{
			    $data = getPostsP();
			    $update_Query = "UPDATE `play` SET `pl_id`='$data[1]',`pl_name`='$data[2]',`pl_author`='$data[3],`pl_timetable`='$data[4]',`pl_roles`='$data[5]',`act_id`='$data[6]' WHERE `pl_id` = $data[0]";
			    try{
			        $update_Result = mysqli_query($conk, $update_Query);
			        
			        if($update_Result)
			        {
			            if(mysqli_affected_rows($conk) > 0)
			            {
			                echo 'Updated!';
			            }else{
			                echo 'No updates!';
			            }
			        }
			    } catch (Exception $ex) {
			        echo 'Error Update '.$ex->getMessage();
			    }
			}
?>



	
</body>

<form action="plays.php" method="post"><br><br>
      <input type="number" name = "pl_id" placeholder = "id" value="<?php echo $pl_id;?>"><br><br>
		<input type="text" name = "pl_name" placeholder = "name" value="<?php echo $pl_name;?>"><br><br>
		<input type="text" name = "pl_author" placeholder = "author" value="<?php echo $pl_author;?>"><br><br>
		<input type="datetime-local" name = "pl_timetable" placeholder = "timetable" value="<?php echo $pl_timetable;?>"><br><br>
		<input type="text" name = "pl_roles" placeholder = "roles" value="<?php echo $pl_roles;?>"><br><br>
		<input type="number" name = "act_id" placeholder = "actors id" value="<?php echo $act_id;?>"><br><br>
		

		<div>
		    <input type="submit" name = "add" value="Add play">
			<input type="submit" name = "delete" value="Delete play">
			<input type="submit" name = "update" value="Update the table">
		</div>
	</form>
</html>