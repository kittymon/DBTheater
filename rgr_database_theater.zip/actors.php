<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Plays page</title>
<link rel="stylesheet" type="text/css" href="sub2style.css">
</head>
<body>
<?php
$conk = new mysqli("localhost", "root","youcandoit09","theater");
if($conk->connect_error){
    die("Error: " . $conk->connect_error);
}
?>
</body>
<h2> Please, choose a page for your further work by clicking one button here: </h2>

	<div>
	<button onclick="window.location.href = 'actor.php';">Cast</button>
    <button onclick="window.location.href = 'plays.php';" >Plays</button>
		</div>
</html>